'''
gere numeros pares no intervalo de 29 e 10
for x in range(Valor inicial, valor final, intervalo de numeros pra pular):
'''
for x in range(30,10, -2):
  print(x) 