import MinhasFuncoes
def main():
    x=MinhasFuncoes.lerElementos(5)
    s=MinhasFuncoes.somar(x)
    m=s/len(x)
    print ("Media ", m)

main()