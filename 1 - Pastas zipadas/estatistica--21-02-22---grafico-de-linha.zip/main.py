import numpy as np
import matplotlib.pyplot as plt

x = np.arange(0,125,5)

y1 = np.random.uniform(-10,2, len(x))
y2 = np.random.uniform (0,20,len(x

fig,ax=plt.subplots()
ax.set_xlabel('X')
ax.set_ylabel('Y1')
plt.show ()

