n=27
while n<=577:
  print (n)
  n=n+2