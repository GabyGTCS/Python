num= [1,2,3,4,5,6]
print("Lista Inicial ", num)
novo = num [:3]
print(novo)
novo=novo+[7,8]
print(novo)
novo=novo+num[3:]
print(novo)
'''
Dessa forma a gente substitui o "novo" por uma nova Lista
'''
