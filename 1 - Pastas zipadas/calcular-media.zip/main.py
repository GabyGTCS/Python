n1=float(input())
n2=float(input())
n3=float(input())
m=(n1*2+n2*3+n3*5)/10
print ("Média= %.1f"%m)