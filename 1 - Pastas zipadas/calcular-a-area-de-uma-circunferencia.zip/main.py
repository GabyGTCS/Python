r=float(input("Insira o raio da Circunferência: "))
a=3.14159265359*(r**2)
print ("A area da Circunferência é igual a: %2.f"%a)
