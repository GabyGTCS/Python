'''
gere numeros pares no intervalo de 10 a 29
for x in range(Valor inicial, valor final +1, intervalo de numeros pra pular):
'''
for x in range(10, 30, 2):
  print(x) 
