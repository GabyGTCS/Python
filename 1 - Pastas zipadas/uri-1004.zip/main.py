A = int(input())
B = int(input())
PROD = A*B
print("PROD = %i" %PROD)