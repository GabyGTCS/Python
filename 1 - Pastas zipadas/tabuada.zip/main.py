import  MinhasFuncoes
def main():
    x=int(input("Valor: "))

    r=MinhasFuncoes.tabuada(x)
print (r)