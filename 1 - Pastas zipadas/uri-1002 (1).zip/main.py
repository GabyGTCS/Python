raio = float(input())
n = 3.14159
area = n*raio**2
print("A=%.4f" %area)