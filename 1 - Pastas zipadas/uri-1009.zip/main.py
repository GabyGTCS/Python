nome = input()
salario = float(input())
total_vendas = float(input())
TOTAL = (total_vendas*15/100)+salario
print ("TOTAL = R$ %.2f" %TOTAL)
