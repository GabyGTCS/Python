N=int(input("Digite o Valor de 'N'"))
n=1
if N>1:
  while n<=N:
    print (n)
    n=n+1
else:
  while N<=n:
    print (N)
    N=N+n
