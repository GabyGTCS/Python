n1=int(input("Valor 1:"))
n2=int(input("valor 2:"))

if n2!=0:
    
    r=n1/n2
    
    print("Resultado ", r)
    
else:
    print("Erro de Divisão por zero")