'''
o que foi escrito dentro dos parentes seria o parâmetro
'''
def mensagem1(nome):
    print ("Olá" + nome)

def mensagem2():
    idade=2020-y
    print (idade)
    
def mensagem3():
    return "Olá"


