n=int(input("Tabuada de: "))
N=1
while N<=10:
 print ("{}+{}={}".format(N,n,N+n))
 N=N+1
