A = int(input())
B = int(input())
SOMA = A+B
print("SOMA = %i" %SOMA)