A = float(input())
B = float(input())

MEDIA = (A*3.5 + B*7.5)/11

print ("MÉDIA = %.5f" %MEDIA)
