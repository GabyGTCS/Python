n=200
while n>=100:
  print (n)
  n=n-2