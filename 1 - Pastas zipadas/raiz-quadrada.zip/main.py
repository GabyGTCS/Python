n=int(input("Digite um numero para descobrir a raiz: "))

r = n**0.5

if n <= 0:
    
    print("nao existe raiz")

else:

    print("a raiz é = %1.f" %r)