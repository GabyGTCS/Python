n1=int(input("Valor 1: "))
n2=int(input("Valor 2: "))

if  n1==n2:
    
    print("Os valores São iguais")
    
else:
    
    if n1>n2:
        
        print("Maior que n2")
    else:
        print("Menor que n2")
print ("encerreio comparação de igualdade")