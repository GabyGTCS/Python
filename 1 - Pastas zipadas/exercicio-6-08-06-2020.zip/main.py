'''
Gerar duas listas (listaAe listaB) de 100 posições 
cada uma com números inteiros gerados aleatoriamente. 
Em seguida, gere uma nova lista com a listaA e listaB concatenadas. 
Elabore as instruções que concatenem as listas, não use o símbolo +.
'''
