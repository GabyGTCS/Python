import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams.update({'font.size':14})

df = pd.DataFrame ({'Tipo de Defeito':['Atraso Entrega', 'Atraso Transportadora', 'Produto Danificado', 'Faturamento Incorreto', 'Separação Incorreta', 'Pedido Errado', 'Preco Errado', 'Outros'], 'Fi (%)':[140, 125, 65 , 59 , 44, 30, 17, 19]})

df ['F.Acum (%)'] = df ['Fi (%)'].cumsum()/df['Fi (%)'].sum()*100

print (df)