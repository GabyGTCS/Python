import random

def d3():
        z=random.randint (1,3)
        return z
def d4():
        z=random.randint (1,4)
        return z
def d5():
        z=random.randint (1,5)
        return z

def d6():
        z=random.randint (1,6)
        return z
def d10():
        z=random.randint(1,10)
        return z
def d8():
        z = random.randint(1,8)
        return z
def d20():
        z = random.randint(1,20)
        return z
def d100():
        z = random.randint(1,20)
        return z
