R=float(input())
pi=3.14159
vol=(4.0/3)*pi*R**3
print ("VOLUME = %.3f"%vol)