from random import randint
x=1
while x==1:
    y=int(input("Digite o n de faces do dado: "))
    z=randint(1,y)
    print(" ____ ")
    print ("| %d |" %z)
    print(" ____ ")