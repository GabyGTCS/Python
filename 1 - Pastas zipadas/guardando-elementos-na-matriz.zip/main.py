grelha=[0]*3
for linha in range(len(grelha)):
    grelha[linha]=[0]*3
    for coluna in range (len(grelha[linha])):
        grelha[linha][coluna] = int(input("Digite um Valor: "))
print(grelha)