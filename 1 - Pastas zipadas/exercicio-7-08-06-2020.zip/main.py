'''
INTERCALAÇÃO
*Nesse exercício vamos pensar q todos tem o mesmo tamanho
Vamos pegar uma relação Logica
Pegar o indice de A e multiplicar por 2 para transportar pra C (i*2)
Pegar o indice de B e multiplicar por 2 e somar 1 para transportar pra C (i*2+1)
'''