N=int(input("Digite o Valor de 'N'"))
n=1
while n<=N:
  print (n)
  n=n+1