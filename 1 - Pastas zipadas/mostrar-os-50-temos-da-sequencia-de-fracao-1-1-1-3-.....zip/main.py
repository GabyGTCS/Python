


c=1
x=1
s=0
while c<50:
    s+=(1/x)
    x+=2
    c+=1
print ("Resultado da Espressão: %f" %s)